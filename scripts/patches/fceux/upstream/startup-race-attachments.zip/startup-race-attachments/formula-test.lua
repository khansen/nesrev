emu.speedmode("maximum")
for frame = 1,60 do emu.frameadvance() end
local result = assert(io.open("result.txt", "w"))
result:write(memory.readbyte(0) .. "\n")
result:close()
emu.exit()
