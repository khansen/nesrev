# Reviewer-reported debugger observations

Source: the independent review supplied on 2026-10-18, by Claude Opus 5.5.
No lldb transcript was saved. This document records that report; it is not
transcribed terminal output and does not establish the precise commands used.

Both inspections used fresh copies of the revision-2 FCEUX build containing the
config patch. The unmodified Homebrew keg was not inspected with lldb.

| State | reqEmuLock | mutexLocks | Number of reported reads |
|---|---|---|---|
| Stalled (`lldb-l1`) | 1 | 0 | 2 |
| Healthy (`lldb-l2`) | 0 | 1 | 2 |

Both used `maximum-supervised.lua`, which writes COMPLETE after 60 frames and
continues advancing frames indefinitely. The retained stalled trace stops at
FRAME 1; the healthy trace reaches COMPLETE. The trace files do not themselves
contain the debugger counter values.
