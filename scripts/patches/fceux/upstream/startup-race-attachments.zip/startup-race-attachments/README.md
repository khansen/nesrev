# Startup-race issue attachments

These artifacts came from the independent reviewer's existing runs. They were
copied and checked without executing an emulator or debugger again.

- `sample.txt`: full sample of `fceux-resign5`, a fresh copy of the revision-2
  build containing the config patch. The emulator thread yields in
  fceuWrapperUpdate; the GUI thread mostly waits in its event loop.
- `resign5-l1/`: that sample's trace and emulator log; trace ends at FRAME 1.
- `lldb-l1/`, `lldb-l2/`: stalled and healthy revision-2 debugger-run logs/traces.
  `DEBUGGER_OBSERVATIONS.md` records the reported counters. No transcript exists.
- `keg/k0-l1/` through `keg/k2-l2/`: three first/repeat launch pairs from fresh
  unmodified corrected-release keg copies. First launches have no result file;
  each repeat launch has result.txt containing 42 followed by a newline.
- `keg2/`: logs for the four reported warm-up/wait controls (`kA0-l1`,
  `kA1-l1`, `kB0-l1`, `kB1-l1`); A0 and B0 have result.txt containing 42.
  The reviewer confirmed the treatments from the launch commands: A copies
  waited 45 seconds; B copies received a `--help` warm-up. Each condition had
  one pass (A0 or B0, result 42) and one stall (A1 or B1).
  These runs use the same formula-test.lua and synthetic ROM as the keg pairs.
- `formula-test.lua`: exact keg-test script; writes result.txt, then emu.exit().
- `maximum-exit.lua`: exact sampled-run script; per-frame trace, sentinel
  assertion, COMPLETE, then emu.exit(). Set TRACE_OUT to an absolute output path.
- `maximum-supervised.lua`: exact debugger-run script; same trace/assertion,
  then continues indefinitely. It requires external termination on success too.
- `own-test.nes`: original synthetic NROM fixture, byte-identical to the keg
  test ROM. It writes decimal 42 to RAM address zero and loops.
- `SHA256SUMS`: hashes for every other file in this attachment bundle.

The exact common frontend arguments were:

```text
--no-config 1 --gamegenie 0 --sound 0 --videoDriver 2 --loadlua <lua> <rom>
```

The common environment was QT_QPA_PLATFORM=minimal and SDL_VIDEODRIVER=dummy,
with fresh configuration and home directories per attempt in the reviewer's
harness. The keg harness additionally used LC_ALL=C and its installed Lua search
path. Run the keg script from its output directory; result.txt is relative to
that directory. Use an external timeout. The keg tests had a 30-second limit.

User/session paths in logs were replaced with /review/firstlaunch or /evidence.
Account-specific macOS temporary paths were replaced with <temporary-directory>.
The sample's abbreviated executable paths are normalized to <capture>/.
Its timestamps, timezone, symbols, addresses and sample counts are retained.
Traces and result values were not changed.
No emulator binaries, personal configuration, or raw debugger transcript are in
this bundle. Local provenance outside the bundle retains original hashes/paths.
