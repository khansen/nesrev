local out = assert(io.open(os.getenv("TRACE_OUT"), "w"))
out:write("START\n"); out:flush()
emu.speedmode("maximum")
for frame = 1,60 do
  emu.frameadvance()
  out:write("FRAME " .. frame .. "\n"); out:flush()
end
assert(memory.readbyte(0) == 42, "CPU sentinel missing")
out:write("COMPLETE\n"); out:flush(); out:close()
emu.exit()
